Maor Sharabany - 204709950
-----------------------------

This is a README file for hw6.
Because of storage limit, I uploaded my Website (hw6) as a Zip folder.
In order to access my website you need to extract all the files from the Zip folder and open 'hw6.html' with your internet browser.

In additon, toy can find a source.txt file that contain all the resources I used.

I worked alone and did not collaborate with anyone.

I am locking forward to get yout feedback and continue to work on my website!

Maor Sharabany 204709950
maorshaharabani@gmail.com